local toolName = "TNS|Cosmic Attack|TNE"

local lcdW = LCD_W
local lcdH = LCD_H

----------------------------------------------------
-- GAME VARIABLES
----------------------------------------------------
local background = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/background.png")
local backgroundl2 = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/backgroundl2.png")
local backgroundl3 = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/backgroundl3.png")
local spaceship = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceship.png")
local spaceshipY = Bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshipy.png")
local spaceshipP = Bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshipp.png")
local spaceshipBig = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshipBig.png")
local spaceshipYBig = Bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshipyBig.png")
local spaceshipPBig = Bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshippBig.png")
local lives = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/lives.png")
local xlife = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/xlife.png")
local splash = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/splash.png")
local ssBullet = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/spaceshipbullet.png")
local titleA = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/Chooseyourspaceship.png")
local explosion = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/explosion.png")
local ammopic = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/ammo.png")
local intro = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/intro.png")

local enemyr = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemyr.png")
local enemyg = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemyg.png")
local enemyb = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemyb.png")
local enemyl2 = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemyl2.png")
local enemyl3 = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemyl3.png")
local enBullet = bitmap.open("/SCRIPTS/TOOLS/Cosmic Attack/enemybullet.png")

local shipBullets = {}
local enemyBullets = {}

local enemies = {}
local explosions = {}
local spawnTimer = 0
local crashTimer = 0
local fireSH = 0

local maxAmmo = 50
local ammo = maxAmmo
local ammoPickups = {}
local ammoSpawnedOnce = false
local ammoCooldown = 0

local livesCount = 3

local bossCount = 0
local maxBosses = 10
local bossActive = false
local bossMoveDir = 1

local level = 1
local levelTimer = 0
local showLevelMessage = false

local introTimer = 0
local introPlayed = false

local shipX = 410
local shipY = 121

local shipW = 52
local shipH = 45 

local bulletW = 31
local bulletH = 6

local points = 0
local gameState = "splash"

local currentSpaceship = spaceship

local gameoverTimer = 0
local gameoverVisible = true
local gameOver = false

----------------------------------------------------
-- SPACESHIP SELECTION SCREEN
----------------------------------------------------
local selectedShip = 1

local function drawShipSelect()
    lcd.drawBitmap(background, 0, 0)
    lcd.drawBitmap(titleA, 0, 15)

    lcd.drawBitmap(spaceshipBig, 50,120)
    lcd.drawBitmap(spaceshipYBig, 180,120)
    lcd.drawBitmap(spaceshipPBig, 320,120)

    -- highlight selected
    if selectedShip == 1 then
        lcd.drawRectangle(50,120,105,92,GREY)
    elseif selectedShip == 2 then
        lcd.drawRectangle(180,120,105,92,GREY)
    else
        lcd.drawRectangle(320,120,105,92,GREY)
    end

end
----------------------------------------------------
-- SELECT SPACESHIP
----------------------------------------------------
local function updateShipSelect(event)

    -- Scroll wheel RIGHT
    if event == EVT_ROT_RIGHT then
        selectedShip = selectedShip + 1
        if selectedShip > 3 then selectedShip = 1 end
    end

    -- Scroll wheel LEFT
    if event == EVT_ROT_LEFT then
        selectedShip = selectedShip - 1
        if selectedShip < 1 then selectedShip = 3 end
    end

    -- Confirm selection
    if event == EVT_ENTER_BREAK then
        if selectedShip == 1 then
            currentSpaceship = spaceship
        elseif selectedShip == 2 then
            currentSpaceship = spaceshipY
        else
            currentSpaceship = spaceshipP
        end

        gameState = "game"
    end

end
----------------------------------------------------
-- BACKGROUND
----------------------------------------------------
local function drawBackground()

  if level == 1 then
    lcd.drawBitmap(background, 0, 0)
  elseif level == 2 then
    lcd.drawBitmap(backgroundl2, 0, 0)
  elseif level == 3 then
    lcd.drawBitmap(backgroundl3, 0, 0)
  end

end
----------------------------------------------------
-- TOP BAR
----------------------------------------------------
local function drawTopBar()

  lcd.drawFilledRectangle(0,0,lcdW,30,BLACK)

  local maxLives = 3
  local startX = 10
  local spacing = 30

  for i = 1, maxLives do

    local x = startX + ((i - 1) * spacing)
    local y = -4

    -- always draw heart
    lcd.drawBitmap(lives, x, y)

    -- draw X on lost lives
    if i > livesCount then
      lcd.drawBitmap(xlife, x + 2, y + 12)
    end

  end

  lcd.drawText(lcdW - 100, 5, "Points: "..points, WHITE)

end
--------------------------------------------------
-- CREATE ENEMIES
--------------------------------------------------
local function spawnEnemy()

  local enemy = {}

  local r = math.random(0,2)
  
  if level == 1 then
    if r == 0 then
      enemy.type = "enemyr"
      enemy.w = 38
      enemy.h = 32
      enemy.hp = 1
    elseif r == 1 then
      enemy.type = "enemyg"
      enemy.w = 44
      enemy.h = 34
      enemy.hp = 1
    else 
      enemy.type = "enemyb"
      enemy.w = 43
      enemy.h = 36
      enemy.hp = 1
    end
  elseif level == 2 then
    enemy.type = "enemyl2"
    enemy.w = 34
    enemy.h = 44
    enemy.hp = 1
  elseif level == 3 then
    if bossActive then return end

    enemy.type = "enemyl3"
    enemy.w = 101
    enemy.h = 175
    enemy.hp = 25

    enemy.x = -120
    enemy.y = lcdH/2 - enemy.h/2

    bossActive = true
  end

  enemy.x = -80
  enemy.y = math.random(40, lcdH - enemy.h)

  table.insert(enemies, enemy)

end

----------------------------------------------------
-- ENEMY MOVEMENTS
----------------------------------------------------
local function updateEnemies()

  spawnTimer = spawnTimer + 1

  local spawnRate = 50

  if points >= 15 then
    spawnRate = 25
  elseif points >= 30 then
    spawnRate = 20
  end

  if level ~= 3 and spawnTimer > spawnRate then
    spawnEnemy()
    spawnTimer = 0
  end

  for i = #enemies, 1, -1 do
    local e = enemies[i]

    if level == 3 then
    if e.x < 20 then
      e.x = e.x + 3
    else
      e.y = e.y + (2 * bossMoveDir)

    local topLimit = 30
    local bottomLimit = lcdH - e.h

    if e.y <= topLimit or e.y >= bottomLimit then
      bossMoveDir = -bossMoveDir
    end
    end
  else
    e.x = e.x + 4
  end
    if e.x > lcdW then
      table.remove(enemies, i)
    end
  end

end

----------------------------------------------------
-- DRAW ENEMIES
----------------------------------------------------
local function drawEnemies()

  for i = 1, #enemies do
    local e = enemies[i]

    if e.type == "enemyr" then
      lcd.drawBitmap(enemyr,e.x,e.y)

    elseif e.type == "enemyg" then
      lcd.drawBitmap(enemyg,e.x,e.y)

    elseif e.type == "enemyb" then
      lcd.drawBitmap(enemyb,e.x,e.y)

    elseif e.type == "enemyl2" then
      lcd.drawBitmap(enemyl2, e.x, e.y)

    elseif e.type == "enemyl3" then
      lcd.drawBitmap(enemyl3, e.x, e.y)

    end
  end

end

----------------------------------------------------
-- ENEMY FIRE BULLET FUNCTION
----------------------------------------------------
local function fireEnemyBullets()

    for i = 1, #enemies do
        local e = enemies[i]

        local r = (level == 3) and math.random(0, 70) or math.random(0, 40)

    if r == 0 then
      if level == 3 then
        table.insert(enemyBullets, {x = e.x + e.w, y = e.y + (e.h * 0.03)})
        table.insert(enemyBullets, {x = e.x + e.w, y = e.y + (e.h * 0.29)})
        table.insert(enemyBullets, {x = e.x + e.w, y = e.y + (e.h * 0.71)})
        table.insert(enemyBullets, {x = e.x + e.w, y = e.y + (e.h * 0.97)})
      else
        table.insert(enemyBullets, {x = e.x + e.w,y = e.y + (e.h / 2)})
      end
    end
   end
end
----------------------------------------------------
-- ENEMY UPDATE BULLET
----------------------------------------------------
local function updateEnemyBullets()

    for i = #enemyBullets,1,-1 do

        enemyBullets[i].x = enemyBullets[i].x + 8

        -- remove if off screen
        if enemyBullets[i].x > lcdW then
            table.remove(enemyBullets,i)
        end

    end
end

----------------------------------------------------
-- DRAW ENEMY BULLET
----------------------------------------------------
local function drawEnemyBullets()

    for i,b in ipairs(enemyBullets) do
        lcd.drawBitmap(enBullet, b.x, b.y)
    end

end
----------------------------------------------------
-- DRAW SPACESHIP
----------------------------------------------------
local function drawSpaceship()
    
  if not gameOver then
    if crashTimer > 0 and crashTimer % 4 < 2 then
      return  -- skip drawing ship
    end
  end

  if spaceship then
      lcd.drawBitmap(currentSpaceship,shipX,shipY)
  end

end

----------------------------------------------------
-- UPDATE SPACESHIP MOVEMENTS
----------------------------------------------------

local function updateSpaceship()

    -- Read sticks
    local stickY = getValue(3)  -- CH3 (up/down)
    local stickX = getValue(2)  -- CH2 (left/right)

    if not stickY then stickY = 0 end
    if not stickX then stickX = 0 end

    --------------------------------------------------
    -- Vertical movement (CH3)
    --------------------------------------------------

    local topLimit = 32
    local bottomLimit = lcdH - 50
    local usableHeight = bottomLimit - topLimit

    local normY = (stickY + 1024) / 2048
    shipY = topLimit + (usableHeight * (1 - normY))

    --------------------------------------------------
    -- Horizontal movement (CH2)
    --------------------------------------------------

    local leftLimit = 10
    local rightLimit = lcdW - 60   
    local usableWidth = rightLimit - leftLimit

    local normX = (stickX + 1024) / 2048
    shipX = leftLimit + (usableWidth * (1 - normX))

end

----------------------------------------------------
-- SPACESHIP FIRE BULLET FUNCTION
----------------------------------------------------
local function fireShipBullets()

    local sh = getValue("sh") or 0

    if sh > 0 and fireSH <= 0 and ammo > 0 then
        table.insert(shipBullets,{
            x = shipX,
            y = shipY + 20
        })
        
        ammo = ammo - 1
    end

    fireSH = sh

end

----------------------------------------------------
-- SPACESHIP UPDATE BULLET
----------------------------------------------------
local function updateShipBullets()

    for i = #shipBullets,1,-1 do

        shipBullets[i].x = shipBullets[i].x - 8

        -- remove if off screen
        if shipBullets[i].x < -20 then
            table.remove(shipBullets,i)
        end

    end

end

----------------------------------------------------
-- DRAW SPACESHIP BULLET
----------------------------------------------------
local function drawShipBullets()

    for i,b in ipairs(shipBullets) do
        lcd.drawBitmap(ssBullet, b.x, b.y)
    end

end

----------------------------------------------------
-- DRAW AMMO BAR
----------------------------------------------------
local function drawAmmoBar()

  local barX = 110
  local barY = 5
  local barW = 100
  local barH = 20

  local fillW = (ammo / maxAmmo) * barW

  local color = GREEN
  if ammo <= 20 then color = YELLOW end
  if ammo <= 5 then color = RED end

  lcd.drawFilledRectangle(barX, barY, fillW, barH, color)
  lcd.drawRectangle(barX, barY, barW, barH, WHITE)

  lcd.drawText(barX + barW/2 - 5, barY + 2, ammo, SMLSIZE + GREY)

end

----------------------------------------------------
-- CREATE AMMO 
----------------------------------------------------
local function spawnAmmoPickup()

  table.insert(ammoPickups, {
    x = -40,
    y = math.random(40, lcdH - 50),
    w = 30,
    h = 30
  })

end

----------------------------------------------------
-- UPDATE AMMO 
----------------------------------------------------
local function updateAmmoPickups()

  for i = #ammoPickups, 1, -1 do
    local a = ammoPickups[i]

    a.x = a.x + 4
    a.y = a.y + math.sin(getTime() / 10)

    if a.x > lcdW then
      table.remove(ammoPickups, i)
    end
  end

end
----------------------------------------------------
-- DRAW AMMO 
----------------------------------------------------
local function drawAmmoPickups()

  for i, a in ipairs(ammoPickups) do
    lcd.drawBitmap(ammopic, a.x, a.y)
  end

end

----------------------------------------------------
-- CHECK AMMO COLLISION 
----------------------------------------------------
local function checkAmmoCollisions()

  for i = #ammoPickups, 1, -1 do
    local a = ammoPickups[i]

    if a.x < shipX + shipW and
       a.x + a.w > shipX and
       a.y < shipY + shipH and
       a.y + a.h > shipY then

      ammo = math.min(maxAmmo, ammo + 15)

      table.remove(ammoPickups, i)

      playFile("/SCRIPTS/TOOLS/Cosmic Attack/powerup.wav")

    end
  end

end
----------------------------------------------------
-- CHECK ENEMY BULLET COLLISIONS
----------------------------------------------------

local function updateEnemyBulletCollisions()

  if crashTimer > 0 then
    crashTimer = crashTimer - 1
    return
  end

  for i = #enemyBullets, 1, -1 do
    local e = enemyBullets[i]

      if e.x < shipX + shipW and
      e.x + bulletW > shipX and
      e.y < shipY + shipH and
      e.y + bulletH > shipY then
      
      livesCount = livesCount - 1
      crashTimer = 40

      table.remove(enemyBullets, i)
      playTone(300, 400, 0, PLAY_NOW)
      break

    end
  end

  -- check for game over
  if livesCount <= 0 then
    gameOver = true
    gameoverTimer = 9999
  end

end

----------------------------------------------------
-- CHECK SPACESHIP BULLET COLLISIONS
----------------------------------------------------
local function updateSpaceshipBulletCollisions()

  for i = #shipBullets, 1, -1 do
    local s = shipBullets[i]

    for j = #enemies, 1, -1 do
      local e = enemies[j]

      if s.x < e.x + e.w and
         s.x + bulletW > e.x and
         s.y < e.y + e.h and
         s.y + bulletH > e.y then

        table.remove(shipBullets, i)
        if level == 3 then
          table.insert(explosions, {x = s.x, y = s.y, timer = 3})
          playFile("/SCRIPTS/TOOLS/Cosmic Attack/explosion.wav")
        end
        e.hp = e.hp - 1

        if e.hp <= 0 then
          table.insert(explosions, {x = e.x, y = e.y, timer = 3})
          if level == 3 then
            bossActive = false
            bossCount = bossCount + 1
          end
          table.remove(enemies, j)

          points = points + 1
          playFile("/SCRIPTS/TOOLS/Cosmic Attack/explosion.wav")
        
        end

        break
      end
    end
  end

end
----------------------------------------------------
-- UPDATE EXPLOSION
----------------------------------------------------
local function updateExplosions()

  for i = #explosions, 1, -1 do
    explosions[i].timer = explosions[i].timer - 1

    if explosions[i].timer <= 0 then
      table.remove(explosions, i)
    end
  end

end
----------------------------------------------------
-- DRAW EXPLOSION
----------------------------------------------------
local function drawExplosions()

  for i, e in ipairs(explosions) do
    lcd.drawBitmap(explosion, e.x, e.y)
  end

end
----------------------------------------------------
-- RESET GAME
----------------------------------------------------
local function resetGame()

  shipBullets = {}
  enemyBullets = {}
  enemies = {}
  ammoPickups = {}
  explosions = {}
  ammoSpawnedOnce = false
  ammoCooldown = 0

  spawnTimer = 0
  crashTimer = 0

  livesCount = 3

  shipX = 410
  shipY = 121

  shipW = 52
  shipH = 45 

  bulletW = 31
  bulletH = 6

  points = 0
  level = 1

  bossCount = 0
  bossActive = false
  bossMoveDir = 1
  
  ammo = maxAmmo
  gameState = "select"

  showLevelMessage = false
  levelTimer = 0

  currentSpaceship = spaceship

  gameoverTimer = 0
  gameoverVisible = true
  gameOver = false

end

----------------------------------------------------
-- GAMEOVER FLASHES
----------------------------------------------------
local function gameoverFlash()

  if not gameOver then return end

    gameoverTimer = gameoverTimer + 1

    if gameoverTimer % 20 < 10 then
      gameoverVisible = true
    else
      gameoverVisible = false
    end

end
----------------------------------------------------
-- MAIN LOOP
----------------------------------------------------
local function run(event)

    lcd.clear()

    -- SPLASH SCREEN
    if gameState == "splash" then

      if splash then
        lcd.drawBitmap(splash,0,0)
      end

    if event == EVT_ENTER_BREAK then
      gameState = "intro"
      introTimer = 160
      introPlayed = false
    end

      return 0
    end
    
    -- INTRO SCREEN
    if gameState == "intro" then

      if intro then
        lcd.drawBitmap(intro, 0, 0)
      end

      if not introPlayed then
        playFile("/SCRIPTS/TOOLS/Cosmic Attack/introsound.wav")
        introPlayed = true
      end
      
      if event == EVT_ENTER_BREAK then
        gameState = "select"
      end
      
      introTimer = introTimer - 1

      if introTimer <= 0 then
        gameState = "select"
      end

      return 0
    end

    -- SELECT SPACESHIP SCREEN
    if gameState == "select" then
      updateShipSelect(event)
      drawShipSelect()
      return 0
    end

     -- restart after game over
    if gameOver and event == EVT_ENTER_BREAK then
      resetGame()
    end

    if not gameOver then
      
      --AMMO LOGIC
      if ammoCooldown > 0 then
        ammoCooldown = ammoCooldown - 1
      end

      if points > 32 and ammo <= 6 and ammoCooldown == 0 and #ammoPickups == 0 then
        spawnAmmoPickup()
        ammoCooldown = 260   
      end

      -- Level 1 to Level 2
      if level == 1 and points >= 30 then
        level = 2
        showLevelMessage = true
        levelTimer = 60   

        enemies = {}
        enemyBullets = {}
        shipBullets = {}
        explosions = {}
      end
      
      -- Level 2 to Level 3
      if level == 2 and points >= 65 then
        level = 3
        showLevelMessage = true
        levelTimer = 60

        enemies = {}
        enemyBullets = {}
        shipBullets = {}
        explosions = {}
     end

      if showLevelMessage then
        levelTimer = levelTimer - 1

        if levelTimer <= 0 then
          showLevelMessage = false
        end
      else

      updateSpaceship()
      fireShipBullets()
      updateShipBullets()
      updateSpaceshipBulletCollisions()
      updateEnemies()
      fireEnemyBullets()
      updateEnemyBullets()
      updateEnemyBulletCollisions()
      updateExplosions()
      updateAmmoPickups()
      checkAmmoCollisions()
      
      if level == 3 and not bossActive and bossCount < maxBosses then
        spawnEnemy()
      end

      if level == 3 and bossCount >= maxBosses then
        gameOver = true
      end

      end
    end

    drawBackground()
    drawSpaceship()
    drawEnemies()
    drawShipBullets()
    drawEnemyBullets()
    drawExplosions()
    drawTopBar()
    drawAmmoBar()
    drawAmmoPickups()

    if showLevelMessage then
      local msg = ""

      if level == 2 then
        msg = "LEVEL 1 COMPLETE"
      elseif level == 3 then
        msg = "LEVEL 2 COMPLETE"
      end

      lcd.drawText(lcdW/2, lcdH/2 - 10, msg, CENTER + DBLSIZE + YELLOW)
    end
    
    if gameOver and gameoverVisible then
      lcd.drawText(lcdW/2, lcdH/2 - 10, "GAME OVER", CENTER + DBLSIZE + RED)
    end

    gameoverFlash() 
    
    return 0

end

----------------------------------------------------
return { run=run }

